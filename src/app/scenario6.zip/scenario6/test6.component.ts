import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test6',
  templateUrl: './test6.component.html',
  styleUrls: ['./test6.component.css']
})
export class Test6Component implements OnInit {
public parent;
  constructor() { }

  ngOnInit() {
  }

}
